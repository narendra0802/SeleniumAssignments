package Selenium.Day1;

public class Assignment1 {

	public static void main(String[] args) {
				// TODO Auto-generated method stub
		
		int input=1978251;
		int sum=0;
		int r=1;
		int temp=input;
		while (r!=0) {
			int	quo=temp/10;
			r=temp%10;
			sum +=r;
			temp=quo;
			
		}
		
		System.out.println("Sum of Digits of given input "+input+" is: "+sum);

	}

}
