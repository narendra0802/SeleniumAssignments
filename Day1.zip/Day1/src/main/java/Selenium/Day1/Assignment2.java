package Selenium.Day1;

public class Assignment2 {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lRange=0;
		int oRange=14;
		//int[] array=null;
		for(int i=lRange;i<=oRange;i++) {
			int r=i%2;
			//int j=0;
			if(r==1)
			{
					//array[j]=i;
				System.out.println("Odd number "+i);
			}
			
			
			
		}
		/*System.out.println("Input Range has "+array.length+" odd numbers");
		for(int i=0;i<array.length;i++) {
			
			System.out.println("array index "+i+" is "+array[i]);
			
		}*/
	}

}
