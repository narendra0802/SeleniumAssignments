package Selenium.Day1;

public class Car {
	
	String model;
	int milage;
	char engType;
	float cost=10.333f;
	long chasis=1234456789011l;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car o=new Car();
		o.model="vento";
		o.milage=25;
		o.engType='d';
		System.out.println("Car Model:"+o.model);
		System.out.println("Car cost:"+o.cost);
		System.out.println("Car chasis:"+o.chasis);
		
		
	}

}
