package Selenium.Day1;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int range=6;
		int a=0;
		int b=1;
		System.out.println(a);
		System.out.println(b);
		int temp;
		for(int i=0;i<range;i++)
		{
			temp=a+b;
			System.out.println(temp);
			a=b;
			b=temp;
			
		}
		
	}

}
