package Selenium.Day2;

public class googleCromeDriver {
	
	public static void getUrl(String url) {
		System.out.println("Given "+url+" is opened");
	}
	
	public static String getText()
	{
		String pText="i am on page 3";
		return pText;
	}
	
	public static void isselected(boolean a) {

		if(a) {
	System.out.println("Check box is selected");
}else {
	System.out.println("Check box is not selected");
}
		
	}
	
	public static void main(String[] args) {
		
		getUrl("Google.com");
		System.out.println("Get Text "+getText());
		isselected(true);
		
	}

}
