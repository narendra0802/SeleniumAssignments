package Selenium.Day2;

public class Calculator {
	
	public static int add(int a,int b) {
		 int sum = a+b;
		 return sum;
	}
	
	public static long mul(int i,int j) {
		long mulRes=i*j;
		return mulRes;
	}

	public static float div(int a,int b) {
		float divRes=a/b;
		return divRes;	
	}
	
	public static float sub(float a,float b) {
		float subRes=a-b;
		return subRes;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Addition of 2,3 is: "+add(2,3));
	System.out.println("Difference of 3,0.5 is: "+sub(3,0.5f));
	System.out.println("Multiplication of 12,12344 is: "+mul(12,12344));
	System.out.println("Division of 3,5 is: "+ div(3,5));
				String a="imwer";

	
		
		

	}

}
